import torch as t
from trainer import Trainer
from model import ResNet
import torchvision as tv
from torch.utils.data import DataLoader
from data import ChallengeDataset
import pandas as pd

epoch = 30

model = ResNet()
checkpoint = t.load('./checkpoints/checkpoint_{:03d}.ckp'.format(epoch), map_location=t.device('cpu'))
model.load_state_dict(checkpoint["state_dict"])
crit = t.nn.BCELoss()

# this can be accomplished using the already imported pandas and sklearn.model_selection modules
dataset = pd.read_csv('data.csv', sep=';', header=0)
dataset = ChallengeDataset(dataset, 'val')
data_dl = DataLoader(dataset, batch_size=10)

# set up the optimizer (see t.optim)
optimizer = t.optim.Adam(model.parameters())
# create an object of type Trainer and set its early stopping criterion
trainer_obj = Trainer(model, crit, optimizer, data_dl, data_dl, cuda=False, early_stopping_patience=5)
trainer_obj.val_test()