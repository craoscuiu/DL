import torch as t
import torch.nn as nn
from torch.utils.data import DataLoader
from data import ChallengeDataset
from trainer import Trainer
from matplotlib import pyplot as plt
import numpy as np
import model
import pandas as pd
from sklearn.model_selection import train_test_split

# load the data from the csv file and perform a train-test-split
# this can be accomplished using the already imported pandas and sklearn.model_selection modules
dataset = pd.read_csv('data.csv', sep=';', header=0)
train, val = train_test_split(dataset, test_size=0.20)

# set up data loading for the training and validation set each using t.utils.data.DataLoader and ChallengeDataset objects
train_dataset = ChallengeDataset(train, 'train')
val_dataset = ChallengeDataset(val, 'val')
val_dl = DataLoader(val_dataset, batch_size=10)
train_dl = DataLoader(train_dataset, batch_size=10)

# create an instance of our ResNet model
model = model.ResNet()
#checkpoint = t.load('./checkpoints/checkpoint_{:03d}.ckp'.format(32))
#model.load_state_dict(checkpoint["state_dict"])

# set up a suitable loss criterion (you can find a pre-implemented loss functions in t.nn)
loss = nn.BCELoss() #pos_weight=train_dataset.pos_weight()
# set up the optimizer (see t.optim)
optimizer = t.optim.Adam(model.parameters(), lr=0.001)
# create an object of type Trainer and set its early stopping criterion
trainer_obj = Trainer(model, loss, optimizer, train_dl, val_dl, cuda=True, early_stopping_patience=10)

# go, go, go... call fit on trainer
res = trainer_obj.fit(100)

# plot the results
plt.plot(np.arange(len(res[0])), res[0], label='train loss')
plt.plot(np.arange(len(res[1])), res[1], label='val loss')
plt.yscale('log')
plt.legend()
plt.savefig('losses.png')
