import torch
import torch.nn as nn
from torch.nn import functional as F


class ResBlock(nn.Module):
    def __init__(self, in_channels, out_channels, stride):
        super(ResBlock, self).__init__()
        self.out_channels = out_channels
        self.in_channels = in_channels
        self.stride = stride
        self.input_tensor = None

        # define layers
        self.conv1 = nn.Conv2d(self.in_channels, self.out_channels, 3, self.stride, padding=1)
        self.conv2 = nn.Conv2d(self.out_channels, self.out_channels, 3, 1, padding=1)
        self.conv3 = nn.Conv2d(self.in_channels, self.out_channels, 1, self.stride)
        self.bn1 = nn.BatchNorm2d(self.out_channels)
        self.bn2 = nn.BatchNorm2d(self.out_channels)
        self.bn3 = nn.BatchNorm2d(self.out_channels)

    def forward(self, x):
        self.input_tensor = x
        # skip connection
        skip = self.conv3(x)
        skip = self.bn3(skip)
        # forward ResBlock
        output = self.conv1(x)
        output = self.bn1(output)
        output = F.relu(output)
        output = self.conv2(output)
        output = self.bn2(output)
        output = F.relu(output)

        return output + skip


class ResNet(nn.Module):
    def __init__(self):
        super(ResNet, self).__init__()
        self.conv1 = nn.Conv2d(3, 64, 7, 2, padding=1)
        self.bn1 = nn.BatchNorm2d(64)
        self.maxpool = nn.MaxPool2d(3, 2)
        self.resblock1 = ResBlock(64, 64, 1)
        self.resblock2 = ResBlock(64, 128, 2)
        self.resblock3 = ResBlock(128, 256, 2)
        self.resblock4 = ResBlock(256, 512, 2)
        self.avgpool = nn.AvgPool2d(10)
        self.fc = nn.Linear(512, 2)

    def forward(self, x):
        output = self.conv1(x)
        output = self.bn1(output)
        output = F.relu(output)
        output = self.maxpool(output)
        output = self.resblock1(output)
        output = self.resblock2(output)
        output = self.resblock3(output)
        output = self.resblock4(output)
        output = self.avgpool(output)
        output = torch.flatten(output, start_dim=1)
        output = self.fc(output)
        output = torch.sigmoid(output)

        return output
