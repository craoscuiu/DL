import math
import numpy as np

class EarlyStoppingCallback:

    def __init__(self, patience):
        #initialize all members you need
        self.patience = patience
        self.minimum_loss = np.Infinity
        self.counter = 0

    def step(self, current_loss):
        # check whether the current loss is lower than the previous best value.
        # if not count up for how long there was no progress
        if current_loss < self.minimum_loss:
            self.counter = 0
            self.minimum_loss = current_loss
        else:
            self.counter += 1
        return self.should_stop()

    def should_stop(self):
        if self.counter > self.patience:
            return True
        else:
            return False
        # check whether the duration of where there was no progress is larger or equal to the patience

