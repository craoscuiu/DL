from torch.utils.data import Dataset, DataLoader
import torch
from pathlib import Path
import os
from skimage.io import imread
from skimage.color import gray2rgb
import numpy as np
from torchvision import transforms
import pandas as pd

train_mean = [0.59685254, 0.59685254, 0.59685254]
train_std = [0.16043035, 0.16043035, 0.16043035]


class ChallengeDataset(Dataset):
    def __init__(self, data, mode):
        super().__init__()
        self.data = data
        self.mode = mode
        self.transform_dict = {
            'train': transforms.Compose([
                transforms.ToPILImage(),
                transforms.RandomHorizontalFlip(p=0.5),
                transforms.RandomVerticalFlip(p=0.5),
                #transforms.RandomRotation(degrees=20, expand=True),
                #transforms.Resize((300, 300)),
                transforms.ToTensor(),
                transforms.Normalize(mean=[0.59685254, 0.59685254, 0.59685254],
                                     std=[0.16043035, 0.16043035, 0.16043035]),
            ]),
            'val': transforms.Compose([
                transforms.ToPILImage(),
                transforms.ToTensor(),
                transforms.Normalize(mean=[0.59685254, 0.59685254, 0.59685254],
                                     std=[0.16043035, 0.16043035, 0.16043035]),
            ])
        }
        self._transform = self.transform_dict[mode]

    def __len__(self):
        return len(self.data)

    def __getitem__(self, index):
        if torch.is_tensor(index):
            index = index.tolist()

        img_name = self.data.iloc[index, 0]
        image = imread(img_name)
        label = self.data.iloc[index, 1:]
        label = np.array([label])
        label = torch.tensor(label.astype('float').reshape(-1, 2))

        image = gray2rgb(image)
        if self.transform:
            image = self.transform(image)
        return image.float(), label

    def pos_weight(self):
        label_weights = np.zeros(self.data.shape[1]-1)  # np.zeros(len(self.data[1]))
        for cracks, inactive in zip(self.data.crack, self.data.inactive):
            if cracks == 1:
                label_weights[0] += 1
            if inactive == 1:
                label_weights[1] += 1
        return torch.tensor((self.__len__() - label_weights) / label_weights, dtype=torch.float)

    @property
    def transform(self):
        return self._transform

